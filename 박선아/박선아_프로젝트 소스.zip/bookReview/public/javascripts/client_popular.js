const url = "/popular";

fetch(url) // get방식
.then(res=>{})