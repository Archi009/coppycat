const url = "/myPage"

fetch(url) // get방식
.then(res=>{});

