const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');

const employeeRouter = require('./routes/employee')    // 이거 라우터 추가!


const app = express();


//set views file
app.set('views', path.join(__dirname, 'views'));

//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


// 이게 라우터다! 여기서 만약에 "/employee" 라고 붙이면, employee.js 랑  각종 ejs 전부 앞에다가 /employee 붙여야 함
app.use("/", employeeRouter);

///////////////////////////////////////////////////////////////



// Server Listening
app.listen(3000, () => {
  console.log('Server is running at port 3000');
});